How to run this file:
First you need to down load all the packages listed in requirements.txt
